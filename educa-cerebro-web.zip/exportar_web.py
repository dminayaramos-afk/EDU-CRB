# -*- coding: utf-8 -*-
"""Exporta el checkpoint de Cerebro a un formato que la página web puede leer.

Uso (desde la raíz del repositorio):
    python3 exportar_web.py

Lee  cerebro-main/checkpoints/best.npz
Crea modelo/cerebro-web.json (config, tokenizador, índice de tensores)
     modelo/cerebro-web.bin  (pesos float32 seguidos)
Vuelve a ejecutarlo cada vez que reentrenes el modelo.
"""
import json, os, sys
import numpy as np

CKPT = sys.argv[1] if len(sys.argv) > 1 else os.path.join("cerebro-main", "checkpoints", "best.npz")
DEST = "modelo"

z = np.load(CKPT, allow_pickle=False)
meta = json.loads(str(z["meta"]))
os.makedirs(DEST, exist_ok=True)

tensores, trozos, pos = [], [], 0
for k in z.files:
    if not k.startswith("p__"):
        continue
    a = np.ascontiguousarray(z[k], dtype="<f4")
    tensores.append({"nombre": k[3:], "forma": list(a.shape), "desde": pos, "n": int(a.size)})
    trozos.append(a.reshape(-1))
    pos += a.size

np.concatenate(trozos).tofile(os.path.join(DEST, "cerebro-web.bin"))
salida = {
    "config": meta["config"],
    "fusiones": meta["tokenizador"]["fusiones"],
    "n_parametros": meta.get("n_parametros"),
    "val_loss": meta.get("val_loss"),
    "paso": meta.get("paso"),
    "perfil": meta.get("perfil"),
    "tensores": tensores,
}
with open(os.path.join(DEST, "cerebro-web.json"), "w", encoding="utf-8") as f:
    json.dump(salida, f, ensure_ascii=False, separators=(",", ":"))
print(f"OK: {pos} valores -> {DEST}/ ({pos*4/1e6:.2f} MB)")
